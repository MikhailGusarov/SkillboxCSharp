﻿using Examplе_2541.Entitys;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Examplе_2541.ContextFolder
{
    public class DataContext : DbContext
    {
        public DbSet<Car> Cars{ get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(
                @"Server=(localdb)\MSSQLLocalDB;
                  DataBase=_EntityCoreExamplе2541;
                  Trusted_Connection=True;"
                );
            
        }
    }
}
